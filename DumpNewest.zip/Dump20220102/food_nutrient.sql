-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: food
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nutrient`
--

DROP TABLE IF EXISTS `nutrient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nutrient` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` tinytext,
  `unit_name` tinytext,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2065 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nutrient`
--

LOCK TABLES `nutrient` WRITE;
/*!40000 ALTER TABLE `nutrient` DISABLE KEYS */;
INSERT INTO `nutrient` VALUES (1002,'Nitrogen','G'),(1003,'Protein','G'),(1004,'Fats','G'),(1005,'Carbohydrate','G'),(1007,'Ash','G'),(1008,'Energy','KCAL'),(1009,'Starch','G'),(1010,'Sucrose','G'),(1011,'Glucose','G'),(1012,'Fructose','G'),(1013,'Lactose','G'),(1014,'Maltose','G'),(1018,'Alcohol','G'),(1026,'Acetic acid','MG'),(1032,'Citric acid','MG'),(1038,'Lactic acid','MG'),(1039,'Malic acid','MG'),(1041,'Oxalic acid','MG'),(1044,'Quinic acid','MG'),(1050,'Carbohydrate','G'),(1051,'Water','G'),(1056,'Sorbitol','G'),(1057,'Caffeine','MG'),(1058,'Theobromine','MG'),(1063,'Sugars','G'),(1072,'Carbohydrate','G'),(1075,'Galactose','G'),(1076,'Raffinose','G'),(1077,'Stachyose','G'),(1078,'Xylitol','G'),(1079,'Fiber-total dietary','G'),(1081,'Ribose','G'),(1082,'Fiber-soluble','G'),(1084,'Fiber-insoluble','G'),(1085,'Total fat (NLEA)','G'),(1086,'Total sugar alcohols','G'),(1087,'Calcium','MG'),(1088,'Chlorine','MG'),(1089,'Iron','MG'),(1090,'Magnesium','MG'),(1091,'Phosphorus','MG'),(1092,'Potassium','MG'),(1093,'Sodium','MG'),(1094,'Sulfur','MG'),(1095,'Zinc','MG'),(1096,'Chromium','UG'),(1097,'Cobalt','UG'),(1098,'Copper','MG'),(1099,'Fluoride','UG'),(1100,'Iodine','UG'),(1101,'Manganese','MG'),(1102,'Molybdenum','UG'),(1103,'Selenium','UG'),(1104,'Vitamin A-IU','IU'),(1105,'Retinol','UG'),(1106,'Vitamin A-RAE','UG'),(1107,'Carotene-beta','UG'),(1108,'Carotene-alpha','UG'),(1109,'Vitamin E (alpha-tocopherol)','MG'),(1110,'Vitamin D (D2 + D3)','IU'),(1111,'Vitamin D2 (ergocalciferol)','UG'),(1112,'Vitamin D3 (cholecalciferol)','UG'),(1113,'25-hydroxycholecalciferol','UG'),(1114,'Vitamin D (D2 + D3)','UG'),(1116,'Phytoene','UG'),(1117,'Phytofluene','UG'),(1118,'Carotene-gamma','UG'),(1119,'Zeaxanthin','UG'),(1120,'Cryptoxanthin-beta','UG'),(1121,'Lutein','UG'),(1122,'Lycopene','UG'),(1123,'Lutein + zeaxanthin','UG'),(1124,'Vitamin E (label entry primarily)','IU'),(1125,'Tocopherol-beta','MG'),(1126,'Tocopherol-gamma','MG'),(1127,'Tocopherol-delta','MG'),(1128,'Tocotrienol-alpha','MG'),(1129,'Tocotrienol-beta','MG'),(1130,'Tocotrienol-gamma','MG'),(1131,'Tocotrienol-delta','MG'),(1137,'Boron','UG'),(1146,'Nickel','UG'),(1158,'Vitamin E','MG'),(1159,'cis-beta-Carotene','UG'),(1160,'cis-Lycopene','UG'),(1161,'cis-Lutein/Zeaxanthin','UG'),(1162,'Vitamin C-total ascorbic acid','MG'),(1165,'Thiamin','MG'),(1166,'Riboflavin','MG'),(1167,'Niacin','MG'),(1170,'Pantothenic acid','MG'),(1175,'Vitamin B-6','MG'),(1176,'Biotin','UG'),(1177,'Folate','UG'),(1178,'Vitamin B-12','UG'),(1180,'Choline','MG'),(1181,'Inositol','MG'),(1183,'Vitamin K (Menaquinone-4)','UG'),(1184,'Vitamin K (Dihydrophylloquinone)','UG'),(1185,'Vitamin K (phylloquinone)','UG'),(1186,'Folic acid','UG'),(1187,'Folate (food)','UG'),(1188,'5-methyl tetrahydrofolate (5-MTHF)','UG'),(1190,'Folate (DFE)','UG'),(1191,'10-Formyl folic acid (10HCOFA)','UG'),(1192,'5-Formyltetrahydrofolic acid (5-HCOH4)','UG'),(1194,'Choline (free)','MG'),(1195,'Choline (from phosphocholine)','MG'),(1196,'Choline (from phosphotidyl choline)','MG'),(1197,'Choline (from glycerophosphocholine)','MG'),(1198,'Betaine','MG'),(1199,'Choline(from sphingomyelin)','MG'),(1210,'Tryptophan','G'),(1211,'Threonine','G'),(1212,'Isoleucine','G'),(1213,'Leucine','G'),(1214,'Lysine','G'),(1215,'Methionine','G'),(1216,'Cystine','G'),(1217,'Phenylalanine','G'),(1218,'Tyrosine','G'),(1219,'Valine','G'),(1220,'Arginine','G'),(1221,'Histidine','G'),(1222,'Alanine','G'),(1223,'Aspartic acid','G'),(1224,'Glutamic acid','G'),(1225,'Glycine','G'),(1226,'Proline','G'),(1227,'Serine','G'),(1228,'Hydroxyproline','G'),(1232,'Cysteine','G'),(1233,'Glutamine','G'),(1234,'Taurine','G'),(1235,'Sugars','G'),(1242,'Vitamin E','MG'),(1246,'Vitamin B-12','UG'),(1253,'Cholesterol','MG'),(1257,'Fatty acids (total trans)','G'),(1258,'Fatty acids (total saturated)','G'),(1259,'SFA 4:0','G'),(1260,'SFA 6:0','G'),(1261,'SFA 8:0','G'),(1262,'SFA 10:0','G'),(1263,'SFA 12:0','G'),(1264,'SFA 14:0','G'),(1265,'SFA 16:0','G'),(1266,'SFA 18:0','G'),(1267,'SFA 20:0','G'),(1268,'MUFA 18:1','G'),(1269,'PUFA 18:2','G'),(1270,'PUFA 18:3','G'),(1271,'PUFA 20:4','G'),(1272,'PUFA 22:6 n-3 (DHA)','G'),(1273,'SFA 22:0','G'),(1274,'MUFA 14:1','G'),(1275,'MUFA 16:1','G'),(1276,'PUFA 18:4','G'),(1277,'MUFA 20:1','G'),(1278,'PUFA 2:5 n-3 (EPA)','G'),(1279,'MUFA 22:1','G'),(1280,'PUFA 22:5 n-3 (DPA)','G'),(1281,'TFA 14:1 t','G'),(1283,'Phytosterols','MG'),(1284,'Ergosterol','MG'),(1285,'Stigmasterol','MG'),(1286,'Campesterol','MG'),(1287,'Brassicasterol','MG'),(1288,'Beta-sitosterol','MG'),(1289,'Campestanol','MG'),(1292,'Fatty acids (total monounsaturated)','G'),(1293,'Fatty acids (total polyunsaturated)','G'),(1294,'Beta-sitostanol','MG'),(1296,'Delta-5-avenasterol','MG'),(1298,'Phytosterols','MG'),(1299,'SFA 15:0','G'),(1300,'SFA 17:0','G'),(1301,'SFA 24:0','G'),(1303,'TFA 16:1 t','G'),(1304,'TFA 18:1 t','G'),(1305,'TFA 22:1 t','G'),(1306,'TFA 18:2 ','G'),(1307,'PUFA 18:2 i','G'),(1310,'TFA 18:2 t and t','G'),(1311,'PUFA 18:2 CLAs','G'),(1312,'MUFA 24:1 c','G'),(1313,'PUFA 20:2 n-6 c and c','G'),(1314,'MUFA 16:1 c','G'),(1315,'MUFA 18:1 c','G'),(1316,'PUFA 18:2 n-6 c and c','G'),(1317,'MUFA 22:1 c','G'),(1321,'PUFA 18:3 n-6','G'),(1323,'MUFA 17:1','G'),(1325,'PUFA 20:3','G'),(1329,'Fatty acids (total trans-monoenoic)','G'),(1330,'Fatty acids (total trans-dienoic)','G'),(1331,'Fatty acids(total trans-polyenoic)','G'),(1332,'SFA 13:0','G'),(1333,'MUFA 15:1','G'),(1334,'PUFA 22:2','G'),(1335,'SFA 11:0','G'),(1340,'Daidzein','MG'),(1341,'Genistein','MG'),(1368,'Epigallocatechin-3-gallate','MG'),(1403,'Inulin','G'),(1404,'PUFA 18:3 n-3','G'),(1405,'PUFA 20:3 n-3','G'),(1406,'PUFA 20:3 n-6','G'),(1408,'PUFA 2:4 n-6','G'),(1409,'PUFA 18:3i','G'),(1410,'PUFA 21:5','G'),(1411,'PUFA 22:4','G'),(1412,'MUFA 18:1-11 t (18:1t n-7)','G'),(1414,'PUFA 20:3 n-9','G'),(2000,'Sugars (total including NLEA)','G'),(2003,'SFA 5:0','G'),(2004,'SFA 7:0','G'),(2005,'SFA 9:0','G'),(2006,'SFA 21:0','G'),(2007,'SFA 23:0','G'),(2008,'MUFA 12:1','G'),(2009,'MUFA 14:1 c','G'),(2010,'MUFA 17:1 c','G'),(2012,'MUFA 20:1 c','G'),(2013,'TFA 20:1 t','G'),(2014,'MUFA 22:1 n-9','G'),(2015,'MUFA 22:1 n-11','G'),(2016,'PUFA 18:2 c','G'),(2017,'TFA 18:2 t','G'),(2018,'PUFA 18:3 c','G'),(2019,'TFA 18:3 t','G'),(2020,'PUFA 20:3 c','G'),(2021,'PUFA 22:3','G'),(2022,'PUFA 2:4 c','G'),(2023,'PUFA 2:5 c','G'),(2024,'PUFA 22:5 c','G'),(2025,'PUFA 22:6 c','G'),(2026,'PUFA 20:2 c','G'),(2028,'trans-beta-Carotene','UG'),(2029,'trans-Lycopene','UG'),(2032,'Cryptoxanthin-alpha','UG'),(2033,'Total dietary fiber (AOAC 2011.25)','G'),(2047,'Energy (Atwater General Factors)','KCAL'),(2048,'Energy (Atwater Specific Factors)','KCAL'),(2049,'Daidzin','MG'),(2050,'Genistin','MG'),(2051,'Glycitin','MG'),(2052,'Delta-7-Stigmastenol','MG'),(2053,'Stigmastadiene','MG'),(2057,'Ergothionine','MG'),(2059,'Vitamin D4','UG'),(2060,'Ergosta-7-enol','MG'),(2061,' Ergosta-7 (22-dienol)','MG'),(2062,' Ergosta-5 (7-dienol)','MG'),(2063,'Verbascose','G');
/*!40000 ALTER TABLE `nutrient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-02 23:52:38
